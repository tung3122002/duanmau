<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
    <link rel="stylesheet" href="../view/index.css">
</head>
<body>
    <div class="container1">
        <div class="row1 mb header">
        <h1>  Siêu Thị Trực Tuyến</h1>

        </div>
        <div class="row1 mb menu">
         <ul class="menu">
             <li class="li1"><a href="./../index.php">TRANG CHỦ</a></li>
             <li class="li1"><a href="index.php?index=adddm">DANH MỤC</a></li>
             <li class="li1"><a href="index.php?index=addsp">HÀNG HÓA</a></li>
             <li class="li1"><a href="index.php?index=dskh">KHÁCH HÀNG</a></li>
             <li class="li1"><a href="index.php?index=dsbl">BÌNH LUẬN</a></li>
             <li class="li1"><a href="index.php?index=thongke">THỐNG KÊ</a></li>
         </ul>
    </div> 